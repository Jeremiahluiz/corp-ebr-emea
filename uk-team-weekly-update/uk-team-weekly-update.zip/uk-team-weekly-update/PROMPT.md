# Reusable prompt

You are preparing my weekly presentation-style HTML update for the UK Sales Team I support.

Create one self-contained HTML file with two presentation sections. The page must be ready to present in Google Chrome, concise, responsive, and readable in a team meeting. Use inline CSS and JavaScript only. Do not require external assets, libraries, fonts, or a build step.

## Reporting period

- `LAST WEEK` means the previous completed Monday through Sunday in CET.
- Show the exact reporting dates on the page.
- Use CET for all dates and timestamps.

## Team scope

Only include Bouke Kingma's activity related to Accounts owned by:

- Louis Leccia (EDU)
- Lidiya Melnyk
- Amy James
- Jose Pezzi
- Frank Jensen

Exclude activity for any other sales team.

## Before collecting data

Ask these questions one at a time:

1. Have you updated your Excel prospecting tracker through the end of LAST WEEK?
2. What were the main prospecting campaigns you ran last week?
3. What worked or did not work in last week's prospecting?
4. What do you need help with from the sales team this week?

Read the tracker from the supplied OneDrive or SharePoint URL. If the link is missing or inaccessible, ask for it. If the user explicitly approves continuing without it, clearly identify the coverage limitation.

## Accounts and activities

Use the tracker, Salesforce activity, and Outreach-synced Salesforce Tasks.

Include only completed activity owned by Bouke Kingma during LAST WEEK.

Count every distinct completed email or call Task as one activity. Repeated contact with the same Account, Contact, or Lead counts separately. Do not deduplicate by Account, subject, timestamp, campaign, Contact, Lead, or recipient. Deduplicate only identical Salesforce Task IDs or confirmed identical Outreach activity IDs.

For Contact activity, use the Contact's Account and Account owner.

For Lead activity, use:

- `Lead.Account__c`
- `Lead.Account__r.Name`
- `Lead.Account__r.Owner.Name`

Do not use the free-text Lead Company field when `Lead.Account__c` exists.

Only include activity whose Account owner is one of the five listed AEs.

Calculate total completed outbound activities, emails, calls, and unique Accounts touched. Emails plus calls must equal total activities.

Derive unique Accounts from the same final Task population. Deduplicate unique Accounts separately using Salesforce Account ID.

Use Salesforce report `JR Corp EMEA EBR- Activities This Week` as the control population after setting the report to LAST WEEK. If the report cannot be executed, request a report export or control total. Resolve discrepancies before creating the final page and never invent missing data.

## Meetings booked

Count customer or prospect meetings booked by Bouke during LAST WEEK, regardless of when the meeting will occur.

- Use the booking or creation date, not the meeting date.
- Connect each meeting to the Account and responsible AE.
- Exclude internal, cancelled, duplicate, and rescheduled meetings.

## Account Recommendations

Collect current Salesforce Account Recommendations for Accounts belonging to the five AEs.

- Include only recommendations whose current status is `New`.
- Treat this as a current snapshot, not a LAST WEEK creation cohort.
- Show totals by AE and for the team.
- Group recommendations by Topic or Sales Play.
- Show the three to five most common themes, their recommendation counts, and the number of affected AEs.
- Do not show a detailed recommendation or Account-level list.

## Presentation section 1

Heading:

`UK Team Prospecting Update | LAST WEEK: [start date] to [end date]`

Include:

- A dominant full-width card for Main prospecting campaigns.
- A separate area within that card for What worked / what did not work.
- Three matching KPI cards underneath:
  - Unique Accounts touched
  - Meetings booked last week
  - Completed outbound activities, including email and call split
- A compact AE table with:
  - Account Executive
  - Unique Accounts touched
  - Account names as horizontal comma-separated lists
  - Meetings booked

Include all five AEs, including zero rows.

## Presentation section 2

Heading:

`Account Recommendations and Next-Week Plan`

Include:

- Total current New recommendations
- New recommendation count by AE
- Three to five most common recommendation themes
- No more than three proposed actions tied to observed themes and relevant AE groups
- A visually separate Need help on section using the manual input

Label recommendation data:

`Current NEW recommendations snapshot`

## HTML design and behavior

- Use one self-contained `.html` file.
- Create two full-width presentation sections with a clean business layout.
- Optimize for a 16:9 laptop screen and Chrome full-screen presentation.
- Support vertical scrolling and keyboard navigation between sections.
- Include Previous and Next controls or clear keyboard guidance.
- Add print styles that produce two clean pages.
- Keep all text inside its card or table.
- Avoid horizontal scrolling.
- Keep every Account name visible.
- Add a small footer on each section with sources used and generation timestamp in CET.
- Escape all data inserted into the HTML.
- Do not include credentials, tokens, Salesforce record IDs, or internal URLs.

## Final validation and delivery

Before delivery, verify all data and reconciliation rules, that both sections render without clipping or overflow, that navigation works, and that print output produces two pages.

Use this filename:

`UK-Team-Prospecting-Update-[LAST-WEEK-START]-to-[LAST-WEEK-END].html`

Open the completed page in Google Chrome. Then provide the actual HTML file as a downloadable attachment or artifact with the label:

`Download the UK Team Prospecting Update`

If Chrome cannot be opened, provide the artifact and clearly state the limitation.
