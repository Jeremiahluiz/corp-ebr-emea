# UK Team Weekly Update skill

This package installs the personal, user-invocable Copilot skill:

`/uk-team-weekly-update`

## Package contents

Keep the complete `uk-team-weekly-update` folder together:

```text
uk-team-weekly-update/
├── SKILL.md
├── PROMPT.md
├── README.md
└── references/
    ├── workflow.md
    ├── page-layout.md
    └── validation.md
```

Do not install `SKILL.md` by itself. The bundled references contain required workflow, layout, and validation rules.

## Install

1. Open the GitHub Copilot app and sign in.
2. In the sidebar, click **Customize**, then select **Skills**.
3. Use the available option to add a local skill folder.
4. Select the extracted `uk-team-weekly-update` folder that directly contains `SKILL.md`.
5. Quit and reopen the GitHub Copilot app.
6. Open **Customize → Skills**, confirm `uk-team-weekly-update` is installed and enabled, then start a new chat.

The available controls can vary by app version. If no local-folder option is shown, install the complete folder manually:

### macOS fallback

1. In Finder, choose **Go → Go to Folder**.
2. Enter `~/.copilot`.
3. Create a folder named `skills` if it is missing.
4. Move the complete folder to `~/.copilot/skills/uk-team-weekly-update`.

### Windows fallback

1. Open File Explorer.
2. Enter `%USERPROFILE%\.copilot` in the address bar.
3. Create a folder named `skills` if it is missing.
4. Move the complete folder to `%USERPROFILE%\.copilot\skills\uk-team-weekly-update`.

Avoid an extra nested folder. `SKILL.md` must be directly inside `uk-team-weekly-update`, not inside a second folder with the same name.

Official documentation:

- [Customize the GitHub Copilot app](https://docs.github.com/en/copilot/how-tos/github-copilot-app/customize-github-copilot-app)

## Troubleshooting installation

- If the skill is not listed, check **Customize → Skills**.
- Confirm `SKILL.md` is directly inside the selected `uk-team-weekly-update` folder.
- For manual installation, confirm the folder is at `~/.copilot/skills/uk-team-weekly-update` on macOS or `%USERPROFILE%\.copilot\skills\uk-team-weekly-update` on Windows.
- Quit and reopen the GitHub Copilot app after changing the folder.

## Prerequisites

The user running the skill needs:

- Revenue MCP access to the required Salesforce objects
- Access to the Salesforce report named `JR Corp EMEA EBR- Activities This Week`
- Salesforce permissions for Tasks, Events, Leads, Contacts, Accounts, and Account Recommendations
- Microsoft 365 and WorkIQ access
- Access to the OneDrive or SharePoint prospecting tracker
- Google Chrome for presenting and visually checking the generated `.html` page

Credentials, tokens, record identifiers, and access permissions are not included.

## Run

Enter:

`/uk-team-weekly-update`

Optional input can include a completed reporting week, tracker URL, or manual campaign responses.

The skill asks four preparation questions one at a time, reconciles the Salesforce activity population to the named control report, and creates one self-contained HTML artifact with two presentation sections.

The output uses inline CSS and JavaScript only, supports scrolling and keyboard navigation, prints as two pages, opens locally in Google Chrome, and requires no external assets or build step.

If Chrome cannot be opened, the skill still provides the HTML artifact and states the limitation.
