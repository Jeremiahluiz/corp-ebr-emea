# UK Team Weekly Update skill

This package installs the personal, user-invocable Copilot skill:

`/uk-team-weekly-update`

## Package contents

Keep the complete `uk-team-weekly-update` folder together:

```text
uk-team-weekly-update/
├── SKILL.md
├── PROMPT.md
├── README.md
└── references/
    ├── workflow.md
    ├── page-layout.md
    └── validation.md
```

Do not install `SKILL.md` by itself. The bundled references contain required workflow, layout, and validation rules.

## Install

1. Install and authenticate Copilot CLI:

   ```shell
   copilot --version
   copilot login
   ```

2. Copy the complete folder to your personal skills directory:

   - macOS: `~/.copilot/skills/uk-team-weekly-update`
   - Windows: `$HOME\.copilot\skills\uk-team-weekly-update`

3. Verify and enable the skill:

   ```shell
   copilot skill list
   copilot skill enable uk-team-weekly-update
   ```

4. Restart Copilot CLI or open a new session.

Official documentation:

- [Install Copilot CLI](https://docs.github.com/en/copilot/how-tos/set-up/install-copilot-cli)
- [Add skills to Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills)

## Prerequisites

The user running the skill needs:

- Revenue MCP access to the required Salesforce objects
- Access to the Salesforce report named `JR Corp EMEA EBR- Activities This Week`
- Salesforce permissions for Tasks, Events, Leads, Contacts, Accounts, and Account Recommendations
- Microsoft 365 and WorkIQ access
- Access to the OneDrive or SharePoint prospecting tracker
- Google Chrome for presenting and visually checking the generated `.html` page

Credentials, tokens, record identifiers, and access permissions are not included.

## Run

Enter:

`/uk-team-weekly-update`

Optional input can include a completed reporting week, tracker URL, or manual campaign responses.

The skill asks four preparation questions one at a time, reconciles the Salesforce activity population to the named control report, and creates one self-contained HTML artifact with two presentation sections.

The output uses inline CSS and JavaScript only, supports scrolling and keyboard navigation, prints as two pages, opens locally in Google Chrome, and requires no external assets or build step.

If Chrome cannot be opened, the skill still provides the HTML artifact and states the limitation.
