---
name: uk-team-weekly-update
description: Prepare Bouke Kingma's weekly two-slide UK sales team PowerPoint update from Salesforce activity, Account Recommendations, Outreach-synced Tasks, Microsoft 365 context, and manual inputs for Louis Leccia, Lidiya Melnyk, Amy James, Jose Pezzi, and Frank Jensen.
user-invocable: true
argument-hint: "[optional: reporting week, tracker URL, or manual inputs]"
---

# UK Team Weekly Update

Create a presentation-ready weekly PowerPoint for Bouke Kingma's UK sales team meeting.

Read and follow these bundled references in order:

1. [Data collection and reconciliation](references/workflow.md)
2. [PowerPoint layout](references/slide-layout.md)
3. [Validation and delivery](references/validation.md)

## Non-negotiable rules

- Ask the four required manual questions one at a time before collecting data.
- Use the previous completed Monday through Sunday in CET unless the user explicitly supplies another completed week.
- Include only activity attributed to Accounts owned by the five named UK AEs.
- Count every distinct completed email or call Task. Repeated contact with the same Lead, Contact, or Account remains separate activity.
- Attribute Lead activity through `Lead.Account__c`, not the free-text Company field.
- Use the named Salesforce activity report as the control total and resolve discrepancies before producing the deck.
- Produce exactly two 16:9 slides.
- Render and visually inspect both slides. No text may extend outside its box.
- Deliver a real `.pptx` file as a downloadable attachment or artifact.

## Invocation

Run:

`/uk-team-weekly-update`

Optional arguments may specify the reporting week, tracker URL, or pre-answer the manual questions.
