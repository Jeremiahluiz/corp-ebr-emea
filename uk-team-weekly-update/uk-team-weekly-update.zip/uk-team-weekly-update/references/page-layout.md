# HTML presentation layout

Create one self-contained `.html` file with inline CSS and JavaScript. Do not require external fonts, images, libraries, network access, or a build step.

The page must:

- Open locally in Google Chrome.
- Use two presentation-style sections that mirror a concise two-part update.
- Use a clean, responsive business layout optimized for a 16:9 laptop screen.
- Support native vertical scrolling and keyboard navigation between sections.
- Remain readable when presented full-screen in Chrome.
- Include print styles that produce two clean pages.
- Avoid horizontal scrolling at common desktop and mobile widths.

## Section 1: Last week's prospecting execution

Heading:

`UK Team Prospecting Update | LAST WEEK: [start date] to [end date]`

### Full-width campaign card

Make this the dominant visual element at the top of the section. It must span the available content width.

Divide the card horizontally into two areas:

1. `MAIN PROSPECTING CAMPAIGNS`
   - Manual input
   - A few words only
2. `WHAT WORKED / WHAT DIDN'T WORK?`
   - Manual input
   - A few words only

These are speaking prompts. Do not turn them into paragraphs.

### Three KPI cards

Place three visually consistent KPI cards underneath the campaign card:

1. Unique Accounts touched
2. Meetings booked last week
3. Completed outbound activities

All three cards must use the same height, corner radius, number placement, label placement, and internal padding.

Place the category label at the bottom of each card.

The activity card must also show:

`[email count] emails | [call count] calls`

### Compact AE table

Place a compact responsive table below the KPI cards.

Columns:

- Account Executive
- Unique Accounts touched
- Accounts prospected
- Meetings booked

Include all five AEs, including zero rows.

Display Account names as horizontal comma-separated lists. Reduce font size slightly or wrap within the row when required, but keep every Account visible and inside the table.

The table must use less visual space than the campaign section. On narrow screens, preserve all data with controlled wrapping rather than hiding columns.

### Coverage note

Add a short note when the tracker, Outreach, Microsoft 365, report execution, or another required source is unavailable or only partially reconciled.

## Section 2: Account Recommendations and next-week plan

Heading:

`Account Recommendations and Next-Week Plan`

Include:

- Total current New recommendations
- Current New recommendations per AE
- Three to five most common recommendation themes or Sales Plays
- Proposed plan for this week
- Need help on

### Proposed plan

Provide no more than three concrete actions.

Tie each action to an observed recommendation theme, the relevant AE group, and a customer or prospecting outcome.

Keep descriptions short enough to remain inside their cards.

### Need help on

This must be its own visually distinct section. It must not be placed inside the proposed-plan section.

Use the user's manual input.

## Page controls and footer

- Add a subtle `Section 1 of 2` or `Section 2 of 2` indicator.
- Add compact Previous and Next controls or clear keyboard guidance.
- Support `ArrowUp`, `ArrowDown`, `PageUp`, `PageDown`, `Home`, and `End` navigation.
- Use native browser scrolling. Do not introduce a framework.
- On each presentation section, add a small footer containing the sources used and generation timestamp in CET.

Label recommendation data:

`Current NEW recommendations snapshot`

## File behavior

- Use semantic HTML.
- Keep all CSS and JavaScript inline.
- Escape all data inserted into HTML.
- Keep the core content usable if JavaScript is disabled.
- Do not include credentials, secrets, Salesforce record IDs, or internal URLs.
- Open the completed file in Google Chrome after generation.
- If Chrome cannot be opened, provide the HTML artifact and clearly state the limitation.
