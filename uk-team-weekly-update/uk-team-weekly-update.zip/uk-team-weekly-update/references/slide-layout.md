# PowerPoint layout

Create a real `.pptx` presentation with exactly two slides in a clean 16:9 business layout.

## Slide 1: Last week's prospecting execution

Title:

`UK Team Prospecting Update | LAST WEEK: [start date] to [end date]`

### Full-width campaign card

Make this the dominant visual element at the top of the slide. It must span almost the full slide width.

Divide the card horizontally into two sections:

1. `MAIN PROSPECTING CAMPAIGNS`
   - Manual input
   - A few words only
2. `WHAT WORKED / WHAT DIDN'T WORK?`
   - Manual input
   - A few words only

These are speaking prompts. Do not turn them into paragraphs.

### Three KPI cards

Place three visually consistent cards underneath the campaign card:

1. Unique Accounts touched
2. Meetings booked last week
3. Completed outbound activities

All three cards must use the same height, corner radius, number placement, label placement, and internal padding.

Place the category label at the bottom of each card.

The activity card must also show:

`[email count] emails | [call count] calls`

### Compact AE table

Place a compact table below the KPI cards.

Columns:

- Account Executive
- Unique Accounts touched
- Accounts prospected
- Meetings booked

Include all five AEs, including zero rows.

Display Account names as horizontal comma-separated lists. Reduce font size slightly or wrap within the row when required, but keep every Account visible and inside the table.

The table must use less visual space than the campaign section.

### Coverage note

Add a short note when the tracker, Outreach, Microsoft 365, report execution, or another required source is unavailable or only partially reconciled.

## Slide 2: Account Recommendations and next-week plan

Title:

`Account Recommendations and Next-Week Plan`

Include:

- Total current New recommendations
- Current New recommendations per AE
- Three to five most common recommendation themes or Sales Plays
- Proposed plan for this week
- Need help on

### Proposed plan

Provide no more than three concrete actions.

Tie each action to:

- An observed recommendation theme
- The relevant AE group
- A customer or prospecting outcome

Keep descriptions short enough to remain inside their boxes.

### Need help on

This must be its own visually distinct section. It must not be placed inside the proposed-plan section.

Use the user's manual input.

## Footer

On each slide, add a small footer containing:

- Sources used
- Generation timestamp in CET

Label recommendation data:

`Current NEW recommendations snapshot`
