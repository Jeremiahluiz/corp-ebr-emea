# Validation and delivery

## Data validation

Before creating the HTML page, verify:

- Only Bouke Kingma's activity is included.
- Only the five UK AEs are included.
- LAST WEEK is the previous completed Monday through Sunday in CET.
- Contact Tasks use the Contact Account.
- Lead Tasks use `Lead.Account__c`.
- Repeated Lead and Contact touches remain separate activities.
- Only identical Task IDs or confirmed identical Outreach activity IDs are deduplicated.
- Emails plus calls equal total activities.
- The activity population reconciles to the named Salesforce control report.
- Unique Accounts are derived from the same activity population and deduplicated by Account ID.
- Meetings are booked during LAST WEEK, not merely held during LAST WEEK.
- Recommendation totals include only records currently marked New.
- AE totals add up to team totals.

## Public safety validation

The package must not contain:

- Salesforce User IDs
- Salesforce report IDs
- Internal Salesforce URLs
- Credentials or tokens
- Customer or activity record identifiers

Resolve users and reports by name.

## HTML and visual validation

Parse the HTML and open the completed file in Google Chrome before delivery.

Verify:

- Every text element is fully inside its containing card or table.
- No text is clipped, overlapping, or extending below a card.
- KPI labels sit at the bottom of all three cards.
- The campaign card spans the section horizontally and remains the dominant element.
- Account lists remain readable.
- Proposed-plan descriptions remain inside their cards.
- Need help on is a separate section.
- Both presentation sections render correctly at a standard 16:9 laptop viewport.
- The responsive layout avoids unintended horizontal scrolling.
- Previous/Next controls and keyboard navigation work.
- The page remains usable with JavaScript disabled.
- Print preview produces two clean presentation pages.

If text does not fit:

1. Shorten wording without changing meaning.
2. Increase the containing box.
3. Reduce font size slightly.

Do not deliver an unopened or visually unchecked HTML page.

## File delivery

Use this filename:

`UK-Team-Prospecting-Update-[LAST-WEEK-START]-to-[LAST-WEEK-END].html`

After validation:

- Attach or expose the actual `.html` artifact.
- Provide a clearly labelled clickable download link or artifact card: `Download the UK Team Prospecting Update`.
- Open the final local file in Google Chrome.
- Do not finish with only a preview or summary.
- Verify the downloadable file opens and contains both presentation sections.
- If the environment cannot create a direct link, provide the file as a downloadable artifact and state the limitation.
