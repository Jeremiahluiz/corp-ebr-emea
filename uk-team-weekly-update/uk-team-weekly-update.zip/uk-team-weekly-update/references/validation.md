# Validation and delivery

## Data validation

Before creating the deck, verify:

- Only Bouke Kingma's activity is included.
- Only the five UK AEs are included.
- LAST WEEK is the previous completed Monday through Sunday in CET.
- Contact Tasks use the Contact Account.
- Lead Tasks use `Lead.Account__c`.
- Repeated Lead and Contact touches remain separate activities.
- Only identical Task IDs or confirmed identical Outreach activity IDs are deduplicated.
- Emails plus calls equal total activities.
- The activity population reconciles to the named Salesforce control report.
- Unique Accounts are derived from the same activity population and deduplicated by Account ID.
- Meetings are booked during LAST WEEK, not merely held during LAST WEEK.
- Recommendation totals include only records currently marked New.
- AE totals add up to team totals.

## Public safety validation

The package must not contain:

- Salesforce User IDs
- Salesforce report IDs
- Internal Salesforce URLs
- Credentials or tokens
- Customer or activity record identifiers

Resolve users and reports by name.

## Visual validation

Render both slides and inspect them before delivery.

Verify:

- Every text element is fully inside its containing shape.
- No text is clipped, overlapping, or extending below a card.
- KPI labels sit at the bottom of all three cards.
- The campaign card spans the slide horizontally and remains the dominant element.
- Account lists remain readable.
- Proposed-plan descriptions remain inside their boxes.
- Need help on is a separate section.

If text does not fit:

1. Shorten wording without changing meaning.
2. Increase the containing box.
3. Reduce font size slightly.

Do not deliver an unrendered or visually unchecked deck.

## File delivery

Use this filename:

`UK-Team-Prospecting-Update-[LAST-WEEK-START]-to-[LAST-WEEK-END].pptx`

After validation:

- Attach or expose the actual `.pptx` artifact.
- Provide a clearly labelled clickable download link or artifact card: `Download the UK Team Prospecting Update`.
- Do not finish with only a preview, summary, or editing-canvas link.
- Verify the downloadable file opens and contains the final two slides.
- If the environment cannot create a direct link, provide the file as a downloadable artifact and state the limitation.
