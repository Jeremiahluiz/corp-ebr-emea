# Data collection and reconciliation

## Fixed identity and team scope

Activity owner:

- Bouke Kingma

UK Account Executives:

- Louis Leccia (EDU)
- Lidiya Melnyk
- Amy James
- Jose Pezzi
- Frank Jensen

Resolve people by name. Do not require or expose Salesforce User IDs.

Exclude Accounts owned by any other AE, queue, integration user, or sales team.

## Reporting period

`LAST WEEK` is the previous completed Monday through Sunday in CET.

- Show the exact dates on the page.
- Use CET for displayed dates and timestamps.
- Do not substitute a rolling seven-day period or the current partial week.

## Manual questions

Ask these questions one at a time:

1. Have you updated your Excel prospecting tracker through the end of LAST WEEK?
2. What were the main prospecting campaigns you ran last week?
3. What worked or did not work in last week's prospecting?
4. What do you need help with from the sales team this week?

Keep answers 2-4 short. They are speaking prompts, not paragraphs.

The tracker should come from a OneDrive or SharePoint URL. If no URL is configured or supplied:

- Ask for it.
- If the user explicitly approves continuing without it, continue and add a visible coverage note.
- Use WorkIQ for OneDrive or SharePoint access.

## Salesforce activity control report

Primary control report:

- Name: `JR Corp EMEA EBR- Activities This Week`
- Report type: `Activity`

Resolve the report by name. Do not expose a Salesforce report ID or internal Salesforce URL.

Apply the LAST WEEK date range before using the report. Do not reuse the report's current total without updating the date filter.

Use the report's filtered result as the control population for completed emails and calls. If direct report execution is unavailable, reconstruct the population with Salesforce Task queries and request a report export or control total. Never invent missing data.

## Activity population

Include:

- Completed email Tasks
- Completed call Tasks
- Account or Contact-linked Tasks
- Lead-linked Tasks with an associated Salesforce Account

Exclude:

- Planned or incomplete Tasks
- Deleted or cancelled Tasks
- Activity outside LAST WEEK
- Activity owned by anyone other than Bouke Kingma
- Activity attributed to Accounts outside the five-AE UK scope

### Contact and Account attribution

For a Contact-linked Task:

1. Read the Contact's Account.
2. Use the Salesforce Account ID for identity and deduplication.
3. Use the Account owner for AE attribution.
4. Include the Task only when the owner is one of the five UK AEs.

For a Task with a standard `AccountId`:

1. Read `Task.AccountId`.
2. Read `Task.Account.Name`.
3. Read `Task.Account.Owner.Name`.
4. Apply the five-AE owner filter.

### Lead attribution

For a Lead-linked Task, the standard Task `AccountId` may be blank. Do not drop the Task.

Read:

- `Lead.Account__c` as the authoritative associated Account ID
- `Lead.Account__r.Name` as the Account name
- `Lead.Account__r.Owner.Name` as the responsible AE

Include the Task only when `Lead.Account__r.Owner.Name` is one of the five UK AEs.

Do not use the Lead's free-text `Company` field when `Lead.Account__c` is populated.

If `Lead.Account__c` is blank, classify the activity as unattributed. Do not include it in confirmed UK totals unless another explicit Salesforce Account relationship proves ownership.

## Activity counting

Count every distinct completed Salesforce Task as one activity.

Count separately:

- Total activities
- Emails
- Calls

The invariant is:

`Total activities = Emails + Calls`

Repeated outreach remains counted:

- Two emails to two Contacts at the same Account are two activities.
- Two emails to two Leads at the same Account are two activities.
- Multiple emails to the same person are separate when they are separate Salesforce Tasks.
- Activities with the same Account, subject, campaign, sequence, or completion timestamp remain separate.

Never deduplicate based on Account, Contact, Lead, recipient, subject, campaign, sequence, or timestamp.

Deduplicate only when:

- The Salesforce Task ID is identical, or
- The Outreach activity ID is identical and the records are confirmed duplicate representations of one activity.

## Unique Accounts touched

Derive the Account list from the same final activity population used for the activity count.

- Deduplicate only by Salesforce Account ID.
- Count each Account once, regardless of the number of Tasks, Contacts, or Leads.
- Group the Account IDs and names by Account owner.
- Display names as horizontal comma-separated lists.

Do not calculate unique Accounts from a narrower query than the activity total.

## Meetings booked

Count customer or prospect meetings booked by Bouke during LAST WEEK, regardless of the future meeting date.

- Use Salesforce Event creation or booking date.
- Connect the Event to the Account and Account owner.
- Include only the five UK AEs.
- Exclude internal, cancelled, duplicate, and rescheduled Event records.
- Do not count a meeting unless its booking date is verifiable.

Show the team total and count per AE.

## Account Recommendations

Retrieve current Salesforce Account Recommendations for the five named AEs.

Rules:

- Status must currently be `New`.
- This is a current snapshot, not a LAST WEEK creation cohort.
- Show the total per AE and team total.
- Do not expose a detailed recommendation or Account list.
- Group by the attached Product, Type, Topic, or Sales Play.
- Show the three to five most common themes with recommendation count and number of affected AEs.

## Reconciliation order

Before building the HTML presentation:

1. Set the exact LAST WEEK period.
2. Filter activity owner to Bouke Kingma.
3. Collect Account and Contact Tasks.
4. Collect Lead Tasks and attribute through `Lead.Account__c`.
5. Apply the five-AE Account-owner filter.
6. Count every distinct Task, including repeated touches.
7. Calculate email, call, and total activity counts.
8. Derive unique Accounts from that same Task population.
9. Compare the result with the filtered control report.
10. Resolve any mismatch before generating the page.

If the independent count does not match the control report:

- Recheck period, owner, Task status, Task type, Contact Account, Lead `Account__c`, and Account owner.
- Do not silently choose a number.
- Use the report total only after confirming its filters match this workflow.
- If unresolved, clearly label the metric as unreconciled and explain the gap. Do not present it as confirmed.
